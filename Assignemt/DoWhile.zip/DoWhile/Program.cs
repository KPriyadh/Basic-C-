﻿using System;
namespace DoWhile{
    class Program{
        public static void Main(string[] args)
        {
            
            
            do{
                Console.WriteLine("Enter a number:");
                int number = int.Parse(Console.ReadLine());
                if(number%2==0){
                    Console.WriteLine("ODD");
                }
                else{
                    Console.WriteLine("EVEN");

                }
                Console.WriteLine("Do you want to check for another number? yes/no");
                string a = Console.ReadLine();
                if(a=="yes"){
                    break;
                }
                else if(a=="no"){
                    continue;
                }
                
            }while(true);
        }
    }
}
